import Foundation

public class RemoteControlWithUndo:CustomStringConvertible{
  
  var onCommands:[Command]
  var offCommands:[Command]
  var undoCommand:Command
  
  public init(){
    self.onCommands = [Command](repeating: NoCommand(), count: 7)
    self.offCommands = [Command](repeating: NoCommand(), count: 7)
    self.undoCommand = NoCommand()
  }
  
  public func reset(){
    self.onCommands = [Command](repeating: NoCommand(), count: 7)
    self.offCommands = [Command](repeating: NoCommand(), count: 7)
    self.undoCommand = NoCommand()
  }
  
  public func setCommand(slot:Int, onCommand:Command,offCommand:Command){
    onCommands[slot] = onCommand
    offCommands[slot] = offCommand
  }
  
  public func onButtonWasPushed(slot:Int){
    onCommands[slot].execute()
    undoCommand = onCommands[slot]
  }
  
  public func offButtonWasPushed(slot:Int){
    offCommands[slot].execute()
    undoCommand = offCommands[slot]
  }
  
  public func undoButtonWasPushed(){
    undoCommand.undo()
  }
  
  public var description: String {
    get{
      var result = "---------------------------  Remote Control With Undo ------------------------- \n"
      for (index,_) in onCommands.enumerated() {
        let onCommandType = type(of: onCommands[index])
        let offCommandType = type(of: offCommands[index])
        result += "[slot \(index)]  \(onCommandType)  \(offCommandType) \n"
      }
      result += "[undo] \(type(of: undoCommand))"
      return result
    }
  }
  
  
}
