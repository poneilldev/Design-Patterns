import Foundation

public class SimpleRemoteControl {
  var slot:Command?
  
  public init(){}
  
  public func setCommand(command:Command) {
    self.slot = command
  }
  
  public func buttonWasPressed() {
    if let slot = slot {
      slot.execute()
    }
  }
}
