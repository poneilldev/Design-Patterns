import Foundation

public class Light{
 
  var name:String = "Light"
  
  public init(){
    
  }
  
  public init(name:String) {
    self.name = name + " Light"
  }
  
  public func on(){
    print("\(name) is On")
  }
  
  public func off(){
    print("\(name) is Off")
  }
  
}
