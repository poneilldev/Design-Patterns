import Foundation

public class GarageDoor{
  
  public init(){}
  
  public func lightOn(){
    print("Garage Light is On")
  }
  public func lightOff(){
    print("Garage Light is Off")
  }
  public func up(){
    print("GarageDoor is up")
  }
  
  public func down(){
    print("GarageDoor is down")
  }
  public func stop(){
    print("GarageDoor is stop")
  }
}
