import Foundation

public class Stereo{
  
  var name:String = "Light"
  
  public init(){}
  
  public init(name:String) {
    self.name = name + " Stereo"
  }
  
  
  public func on(){
    print("\(name) is On")
  }
  public func Off(){
    print("\(name) is Off")
  }
  
  public func setCD(){
    print("\(name) setCD")
  }
  
  public func setDvd(){
    print("\(name) setDVD")
  }
  
  public func getRadio(){
    print("\(name) getRadio")
  }
  
  public func setVolume(_ volume:Int){
    print("\(name) setting Volume")
  }
  
}
