import Foundation

public class Hottub{
  
  var name:String = "Hottub"
  
  public init(){
    
  }
  
  public init(name:String) {
    self.name = name + " Hottub"
  }
  
  public func on(){
    print("\(name) is On")
  }
  
  public func off(){
    print("\(name) is Off")
  }
  
}
