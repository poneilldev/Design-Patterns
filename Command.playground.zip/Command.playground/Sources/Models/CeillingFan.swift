import Foundation

public enum FanSpeed{
  case high
  case low
  case medium
  case off
}

public class CeillingFan{
  
  var name:String = "CeillingFan"
  var speed:FanSpeed = .off
  
  public init(){}
  
  public init(name:String){
    self.name = name + " CeillingFan"
  }
  
  public func high(){
    speed = .high
    print("\(name) is high")
  }
  
  public func Off(){
    speed = .off
    print("\(name) is Off")
  }
  public func medium(){
    speed = .medium
    print("\(name) is Medium")
  }
  
  public func low(){
    speed = .low
    
    print("\(name) is low")
  }
  
  public func getSpeed() -> FanSpeed{
    return speed
  }
}
