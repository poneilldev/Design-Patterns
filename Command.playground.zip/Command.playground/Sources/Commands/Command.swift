import Foundation

public protocol Command {
  func execute()
  func undo()
}

extension Command {
  public func undo(){
    
  }
}
