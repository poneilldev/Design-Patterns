import Foundation

public class NoCommand:Command{
  public init(){}
  public func execute() {
    print("There is no command!!")
  }
}
