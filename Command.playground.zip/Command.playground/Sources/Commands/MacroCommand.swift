import Foundation

public class MacroCommand:Command{

  var commands:[Command]

  public init(commands:[Command]){
    self.commands = commands
  }
  
  
  public func execute() {
    for (index,_) in commands.enumerated() {
      commands[index].execute()
    }
  }
  
  public func undo() {
    for (index,_) in commands.enumerated() {
      commands[index].undo()
    }
  }
}
