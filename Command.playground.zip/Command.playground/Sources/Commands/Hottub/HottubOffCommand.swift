import Foundation

public class HottubOffCommand: Command {
  var hottub:Hottub
  
  public init(hottub:Hottub){
    self.hottub = hottub
  }
  
  public func execute() {
    hottub.off()
  }
}
