import Foundation

public class HottubOnCommand: Command {
  var hottub:Hottub
  
  public init(hottub:Hottub){
    self.hottub = hottub
  }
  
  public func execute() {
    hottub.on()
  }
}
