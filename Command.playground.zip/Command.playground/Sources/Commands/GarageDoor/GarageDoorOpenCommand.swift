import Foundation

public class GarageDoorOpenCommand:Command {
  
  var garageDoor:GarageDoor
  
  public init(garageDoor:GarageDoor) {
    self.garageDoor = garageDoor
  }
  
  public func execute() {
    self.garageDoor.up()
  }
}
