import Foundation

public class GarageDoorUpCommand:Command {
  
  var garageDoor:GarageDoor
  
  public init(garageDoor:GarageDoor) {
    self.garageDoor = garageDoor
  }
  
  public func execute() {
    self.garageDoor.up()
  }
}
