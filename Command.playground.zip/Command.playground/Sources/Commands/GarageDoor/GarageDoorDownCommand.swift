import Foundation

public class GarageDoorDownCommand:Command {
  
  var garageDoor:GarageDoor
  
  public init(garageDoor:GarageDoor) {
    self.garageDoor = garageDoor
  }
  
  public func execute() {
    self.garageDoor.down()
  }
}
