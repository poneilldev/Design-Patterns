import Foundation

public class TVOffCommand: Command {
  var tv:TV
  
  public init(tv:TV){
    self.tv = tv
  }
  
  public func execute() {
    tv.off()
  }
}
