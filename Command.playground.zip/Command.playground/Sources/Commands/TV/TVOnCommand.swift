import Foundation

public class TVOnCommand: Command {
  var tv:TV
  
  public init(tv:TV){
    self.tv = tv
  }
  
  public func execute() {
    tv.on()
  }
}
