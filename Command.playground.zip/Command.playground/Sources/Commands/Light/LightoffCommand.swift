import Foundation


public class LightoffCommand: Command {
  var light:Light
  
  public init(light:Light){
    self.light = light
  }
  
  public func execute() {
    light.off()
  }
  
  public func undo() {
    light.on()
  }
}
