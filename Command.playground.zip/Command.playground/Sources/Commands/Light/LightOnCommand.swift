import Foundation

public class LightOnCommand: Command {
  var light:Light
  
  public init(light:Light){
    self.light = light
  }
  
  public func execute() {
    light.on()
  }
  
  public func undo() {
    light.off()
  }
}
