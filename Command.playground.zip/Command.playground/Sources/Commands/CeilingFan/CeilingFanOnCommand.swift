import Foundation

public class CeilingFanOnCommand: Command {
  var fan:CeillingFan
  
  public init(fan:CeillingFan){
    self.fan = fan
  }
  
  public func execute() {
    fan.low()
  }
}
