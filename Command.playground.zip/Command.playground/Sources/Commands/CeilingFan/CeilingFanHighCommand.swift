import Foundation

public class CeilingFanHighCommand: Command {
  var fan:CeillingFan
  var prevSpeed:FanSpeed?
  
  public init(fan:CeillingFan){
    self.fan = fan
  }
  
  public func execute() {
    prevSpeed = fan.getSpeed()
    fan.high()
  }
  
  public func undo() {
    switch prevSpeed! {
    case .high:
      fan.high()
    case .low:
      fan.low()
    case .medium:
      fan.medium()
    case .off:
      fan.Off()
    }
  }
}
