import Foundation

public class StereoOffCommand: Command {
  var stereo:Stereo
  
  public init(stereo:Stereo){
    self.stereo = stereo
  }
  
  public func execute() {
    stereo.Off()
  }
}
