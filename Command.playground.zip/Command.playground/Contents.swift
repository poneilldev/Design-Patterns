
//: ========================  SimpleRemoteControl Test  ========================================
/// Test Simple Remote Control

/// Test Light On
var remote:SimpleRemoteControl = SimpleRemoteControl()

var light = Light()
var lightOn = LightOnCommand(light: light)

remote.setCommand(command: lightOn)
remote.buttonWasPressed()


/// Test GarageDoorOpenCommand

var garageDoor = GarageDoor()
var garageDoorOpen = GarageDoorOpenCommand(garageDoor: garageDoor)

/// Override the GarageDoor Command
remote.setCommand(command: garageDoorOpen)
remote.buttonWasPressed()

//: ======================== End SimpleRemoteControl Test  ========================================


//: ========================  RemoteControl Test  ========================================
print("\n\n========================  RemoteControl Test  ========================================\n\n")
var remoteControl:RemoteControl = RemoteControl()

var livingRoomLight = Light(name: "Living Room")
var kitchenLight = Light(name: "Kitchen")
var ceilingFan = CeillingFan(name: "Living Room")
var stereo = Stereo(name: "Living Room")

var livingRoomLightOn = LightOnCommand(light: livingRoomLight)
var livingRoomLightOff = LightoffCommand(light: livingRoomLight)

var kitchenLightOn = LightOnCommand(light: kitchenLight)
var kitchenLightOff = LightoffCommand(light: kitchenLight)

var ceilingFanOn = CeilingFanOnCommand(fan: ceilingFan)
var ceilingFanOff = CeilingFanOffCommand(fan: ceilingFan)

var garageDoorUpCommand = GarageDoorUpCommand(garageDoor: garageDoor)
var garageDoorDownCommand = GarageDoorDownCommand(garageDoor: garageDoor)


var stereoWithCD = StereoOnWithCDCommand(stereo: stereo)
var stereoOff = StereoOffCommand(stereo: stereo)


remoteControl.setCommand(slot: 0, onCommand: livingRoomLightOn, offCommand: livingRoomLightOff)
remoteControl.setCommand(slot: 1, onCommand: kitchenLightOn, offCommand: kitchenLightOff)
remoteControl.setCommand(slot: 2, onCommand: ceilingFanOn, offCommand: ceilingFanOff)
remoteControl.setCommand(slot: 3, onCommand: stereoWithCD, offCommand: stereoOff)

print(remoteControl)

remoteControl.onButtonWasPushed(slot: 0)
remoteControl.offButtonWasPushed(slot: 0)
remoteControl.onButtonWasPushed(slot: 1)
remoteControl.offButtonWasPushed(slot: 1)
remoteControl.onButtonWasPushed(slot: 2)
remoteControl.offButtonWasPushed(slot: 2)
remoteControl.onButtonWasPushed(slot: 3)
remoteControl.offButtonWasPushed(slot: 3)

//: ======================== End RemoteControl Test  ========================================
print("\n\n======================== End RemoteControl Test  ========================================\n\n")


//: ========================  RemoteControl With Undo Test  ========================================
print("\n\n========================  RemoteControl Test  With Undo ========================================\n\n")
var remoteControlWithUndo = RemoteControlWithUndo()


remoteControlWithUndo.setCommand(slot: 0, onCommand: livingRoomLightOn, offCommand: livingRoomLightOff)

remoteControlWithUndo.onButtonWasPushed(slot: 0)
remoteControlWithUndo.offButtonWasPushed(slot: 0)

print(remoteControlWithUndo)
remoteControlWithUndo.undoButtonWasPushed()
remoteControlWithUndo.offButtonWasPushed(slot: 0)
remoteControlWithUndo.onButtonWasPushed(slot: 0)

print(remoteControlWithUndo)
remoteControlWithUndo.undoButtonWasPushed()


//: ======================== End RemoteControl with Undo Test  ========================================
print("\n\n======================== End RemoteControl Test with Undo  ========================================\n\n")


//: ========================  RemoteControlUndo with State  Test  ========================================
print("\n\n========================  RemoteControlUndo with State Test ========================================\n\n")

var ceilingFanMediumCommand = CeilingFanMediumCommand(fan: ceilingFan)
var ceilingFanHighCommand = CeilingFanHighCommand(fan: ceilingFan)

remoteControlWithUndo.setCommand(slot: 0, onCommand: ceilingFanMediumCommand, offCommand: ceilingFanOff)
remoteControlWithUndo.setCommand(slot: 1, onCommand: ceilingFanHighCommand, offCommand: ceilingFanOff)

remoteControlWithUndo.onButtonWasPushed(slot: 0)
remoteControlWithUndo.offButtonWasPushed(slot: 0)
print(remoteControlWithUndo)
remoteControlWithUndo.undoButtonWasPushed()


remoteControlWithUndo.onButtonWasPushed(slot: 1)

print(remoteControlWithUndo)
remoteControlWithUndo.undoButtonWasPushed()


//: ======================== End RemoteControlUndo with State Test  ========================================
print("\n\n======================== End RemoteControlUndo with State Test  ========================================\n\n")


print("\n\n========================  Macro RemoteControl Test ========================================\n\n")

var tv = TV(name: "Living Room")
var hottub = Hottub()

var tvOn = TVOnCommand(tv: tv)
var tvOff = TVOffCommand(tv: tv)

var hottubOn = HottubOnCommand(hottub: hottub)
var hottubOff = HottubOffCommand(hottub: hottub)

var lightOff = LightoffCommand(light: light)

var partyOn:[Command] = [lightOn,stereoWithCD,tvOn,hottubOn]
var partyOff:[Command] = [lightOff,stereoOff,tvOff,hottubOff]

var partyOnMacro = MacroCommand(commands: partyOn)
var partyOffMacro = MacroCommand(commands: partyOff)

remoteControlWithUndo.reset()
remoteControlWithUndo.setCommand(slot: 0, onCommand: partyOnMacro, offCommand: partyOffMacro)

print(remoteControlWithUndo)
print("\n\n----------- PushingMacro On------------------\n\n")
remoteControlWithUndo.onButtonWasPushed(slot: 0)
print("\n\n----------- PushingMacro Off------------------\n\n")
remoteControlWithUndo.offButtonWasPushed(slot: 0)
print("\n\n========================  End Macro RemoteControl Test ========================================\n\n")



